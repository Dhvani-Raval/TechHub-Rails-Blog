require "application_system_test_case"

class PostCommentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit post_comments_url
  #
  #   assert_selector "h1", text: "PostComment"
  # end
end
