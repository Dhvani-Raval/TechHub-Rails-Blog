Rails.application.routes.draw do
resources :post_comments
  
  get 'pages/about'

  get 'pages/contact'

  get 'pages/resources'

  devise_for :admin_users, ActiveAdmin::Devise.config
 
  resources :articles
 
  resources :categories
  get 'categories/index'

  get 'categories/edit'

  get 'categories/new'

  get 'categories/show'

  get 'home/index'
  
  

    resources :posts
	resources :categories
	
	
	get '/about', :to => 'pages#about'
	get '/contact', :to => 'pages#contact'
	get '/resources', :to => 'pages#resources'
    root 'home#index'
	ActiveAdmin.routes(self)
	
end
