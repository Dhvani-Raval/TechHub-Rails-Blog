class AdminUser < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, 
         :recoverable, :rememberable,
		 :validatable 
		 # :trackable
		 
	#attr_accessor :email, :name, :password, :password_confirmation, :remember_me
	has_many :posts
end
