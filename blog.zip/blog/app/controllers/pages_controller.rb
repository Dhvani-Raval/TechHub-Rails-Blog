class PagesController < ApplicationController
  def about
  end

  def contact
  end

  def resources
  end
  
  
end
